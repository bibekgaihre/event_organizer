var express=require('express');
var router=express.Router();
var bodyparser=require('body-parser');

var calenderController=require('../app/controller/calenderController');

router.get('/calenderoverview',calenderController.dashboard);
router.get('/eventcalender',calenderController.calender);
router.get('/eventcalender/getevent',calenderController.getevent);
router.post('/eventcalender/postevent',calenderController.postevent);
router.post('/eventcalender/deleteevent/:eventid',calenderController.deleteevent);
router.post('/eventcalender/updateevent',calenderController.updateevent);
module.exports=router;